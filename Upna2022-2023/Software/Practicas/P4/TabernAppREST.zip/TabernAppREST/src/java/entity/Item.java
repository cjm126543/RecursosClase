/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "ITEM", catalog = "", schema = "TABERNAUSER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Item.findAll", query = "SELECT i FROM Item i")
    , @NamedQuery(name = "Item.findByIditem", query = "SELECT i FROM Item i WHERE i.iditem = :iditem")
    , @NamedQuery(name = "Item.findByNombre", query = "SELECT i FROM Item i WHERE i.nombre = :nombre")
    , @NamedQuery(name = "Item.findByPrecioud", query = "SELECT i FROM Item i WHERE i.precioud = :precioud")
    , @NamedQuery(name = "Item.findByStock", query = "SELECT i FROM Item i WHERE i.stock = :stock")
    , @NamedQuery(name = "Item.findByCantpreparando", query = "SELECT i FROM Item i WHERE i.cantpreparando = :cantpreparando")
    , @NamedQuery(name = "Item.findByIdhorno", query = "SELECT i FROM Item i WHERE i.idhorno = :idhorno")
    , @NamedQuery(name = "Item.findByIdarcon", query = "SELECT i FROM Item i WHERE i.idarcon = :idarcon")
    , @NamedQuery(name = "Item.findByIdseccionalmacen", query = "SELECT i FROM Item i WHERE i.idseccionalmacen = :idseccionalmacen")
    , @NamedQuery(name = "Item.findByPreparando", query = "SELECT i FROM Item i WHERE i.preparando = :preparando")
    , @NamedQuery(name = "Item.findByEnuso", query = "SELECT i FROM Item i WHERE i.enuso = :enuso")})
public class Item implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDITEM")
    private Integer iditem;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "NOMBRE")
    private String nombre;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRECIOUD")
    private BigDecimal precioud;
    @Basic(optional = false)
    @NotNull
    @Column(name = "STOCK")
    private int stock;
    @Column(name = "CANTPREPARANDO")
    private Integer cantpreparando;
    @Column(name = "IDHORNO")
    private Integer idhorno;
    @Column(name = "IDARCON")
    private Integer idarcon;
    @Column(name = "IDSECCIONALMACEN")
    private Integer idseccionalmacen;
    @Column(name = "PREPARANDO")
    private Boolean preparando;
    @Column(name = "ENUSO")
    private Boolean enuso;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idarticuloFg")
    private Collection<Articulopedido> articulopedidoCollection;
    @JoinColumn(name = "TIPO_FG", referencedColumnName = "IDTIPO")
    @ManyToOne(optional = false)
    private Tipo tipoFg;

    public Item() {
    }

    public Item(Integer iditem) {
        this.iditem = iditem;
    }

    public Item(Integer iditem, String nombre, int stock) {
        this.iditem = iditem;
        this.nombre = nombre;
        this.stock = stock;
    }

    public Integer getIditem() {
        return iditem;
    }

    public void setIditem(Integer iditem) {
        this.iditem = iditem;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getPrecioud() {
        return precioud;
    }

    public void setPrecioud(BigDecimal precioud) {
        this.precioud = precioud;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Integer getCantpreparando() {
        return cantpreparando;
    }

    public void setCantpreparando(Integer cantpreparando) {
        this.cantpreparando = cantpreparando;
    }

    public Integer getIdhorno() {
        return idhorno;
    }

    public void setIdhorno(Integer idhorno) {
        this.idhorno = idhorno;
    }

    public Integer getIdarcon() {
        return idarcon;
    }

    public void setIdarcon(Integer idarcon) {
        this.idarcon = idarcon;
    }

    public Integer getIdseccionalmacen() {
        return idseccionalmacen;
    }

    public void setIdseccionalmacen(Integer idseccionalmacen) {
        this.idseccionalmacen = idseccionalmacen;
    }

    public Boolean getPreparando() {
        return preparando;
    }

    public void setPreparando(Boolean preparando) {
        this.preparando = preparando;
    }

    public Boolean getEnuso() {
        return enuso;
    }

    public void setEnuso(Boolean enuso) {
        this.enuso = enuso;
    }

    @XmlTransient
    public Collection<Articulopedido> getArticulopedidoCollection() {
        return articulopedidoCollection;
    }

    public void setArticulopedidoCollection(Collection<Articulopedido> articulopedidoCollection) {
        this.articulopedidoCollection = articulopedidoCollection;
    }

    public Tipo getTipoFg() {
        return tipoFg;
    }

    public void setTipoFg(Tipo tipoFg) {
        this.tipoFg = tipoFg;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iditem != null ? iditem.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Item)) {
            return false;
        }
        Item other = (Item) object;
        if ((this.iditem == null && other.iditem != null) || (this.iditem != null && !this.iditem.equals(other.iditem))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Item[ iditem=" + iditem + " ]";
    }
    
}
