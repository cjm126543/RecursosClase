/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "ARTICULOPEDIDO", catalog = "", schema = "TABERNAUSER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Articulopedido.findAll", query = "SELECT a FROM Articulopedido a")
    , @NamedQuery(name = "Articulopedido.findByIdlinea", query = "SELECT a FROM Articulopedido a WHERE a.idlinea = :idlinea")
    , @NamedQuery(name = "Articulopedido.findByCantidadarticulo", query = "SELECT a FROM Articulopedido a WHERE a.cantidadarticulo = :cantidadarticulo")})
public class Articulopedido implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDLINEA")
    private Integer idlinea;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CANTIDADARTICULO")
    private int cantidadarticulo;
    @JoinTable(name = "LINEASPEDIDO", joinColumns = {
        @JoinColumn(name = "IDLINEA", referencedColumnName = "IDLINEA")}, inverseJoinColumns = {
        @JoinColumn(name = "IDPEDIDO", referencedColumnName = "IDPEDIDO")})
    @ManyToMany
    private Collection<Pedido> pedidoCollection;
    @JoinColumn(name = "IDARTICULO_FG", referencedColumnName = "IDITEM")
    @ManyToOne(optional = false)
    private Item idarticuloFg;

    public Articulopedido() {
    }

    public Articulopedido(Integer idlinea) {
        this.idlinea = idlinea;
    }

    public Articulopedido(Integer idlinea, int cantidadarticulo) {
        this.idlinea = idlinea;
        this.cantidadarticulo = cantidadarticulo;
    }

    public Integer getIdlinea() {
        return idlinea;
    }

    public void setIdlinea(Integer idlinea) {
        this.idlinea = idlinea;
    }

    public int getCantidadarticulo() {
        return cantidadarticulo;
    }

    public void setCantidadarticulo(int cantidadarticulo) {
        this.cantidadarticulo = cantidadarticulo;
    }

    @XmlTransient
    public Collection<Pedido> getPedidoCollection() {
        return pedidoCollection;
    }

    public void setPedidoCollection(Collection<Pedido> pedidoCollection) {
        this.pedidoCollection = pedidoCollection;
    }

    public Item getIdarticuloFg() {
        return idarticuloFg;
    }

    public void setIdarticuloFg(Item idarticuloFg) {
        this.idarticuloFg = idarticuloFg;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idlinea != null ? idlinea.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Articulopedido)) {
            return false;
        }
        Articulopedido other = (Articulopedido) object;
        if ((this.idlinea == null && other.idlinea != null) || (this.idlinea != null && !this.idlinea.equals(other.idlinea))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Articulopedido[ idlinea=" + idlinea + " ]";
    }
    
}
