package com.example.tabernapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tabernapp.Models.Item;
import com.example.tabernapp.Models.Tipo;

import java.util.ArrayList;
import java.util.List;

public class Categoria extends AppCompatActivity {

    // View components
    TabernAppApplication app;

    // Application data manipulation structures
    List<Item> catalogue = new ArrayList<>();
    Item selectedItem;
    Bundle bundle;
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categoria_view);

        // Retrieve selected item on catalogue
        app = (TabernAppApplication) getApplicationContext();
        catalogue = app.getCatalogo();
        bundle = getIntent().getExtras();
        pos = bundle.getInt("listPosition");
        selectedItem = catalogue.get(pos);

        displayCategory(selectedItem.getTipo());

    }

    /**
     * Displays the specified category in the layout.
     * @param categoryType category to implement
     */
    private void displayCategory(Tipo categoryType) {
        // TODO
    }
}