package com.example.tabernapp.Models;

public enum Tipo {
    PAN,
    REPOSTERIA,
    LACTEO,
    REFRESCO,
    SNACK,
    CAFE,
    EXTRA
}
