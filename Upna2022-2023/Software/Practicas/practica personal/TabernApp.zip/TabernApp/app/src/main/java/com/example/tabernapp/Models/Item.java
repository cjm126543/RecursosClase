package com.example.tabernapp.Models;

import androidx.annotation.NonNull;

import java.util.Optional;

public class Item {

    // Attributes
    private String nombre;
    private Tipo tipo;
    private double precioUd;
    private int stock;
    private Optional<Integer> idHorno, idArcon, idSeccionAlmacen;
    private Optional<Boolean> preparando, enUso;

    // Constructor
    public Item(String nombre, Tipo tipo, double precioUd, int stock) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precioUd = precioUd;
        this.stock = stock;
        this.idHorno = null;
        this.idArcon = null;
        this.idSeccionAlmacen = null;
        this.preparando = null;
        this.enUso = null;
    }

    // Getters and setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public double getPrecioUd() {
        return precioUd;
    }

    public void setPrecioUd(double precioUd) {
        this.precioUd = precioUd;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Optional<Integer> getIdHorno() {
        return idHorno;
    }

    public void setIdHorno(Optional<Integer> idHorno) {
        this.idHorno = idHorno;
    }

    public Optional<Integer> getIdArcon() {
        return idArcon;
    }

    public void setIdArcon(Optional<Integer> idArcon) {
        this.idArcon = idArcon;
    }

    public Optional<Integer> getIdSeccionAlmacen() {
        return idSeccionAlmacen;
    }

    public void setIdSeccionAlmacen(Optional<Integer> idSeccionAlmacen) {
        this.idSeccionAlmacen = idSeccionAlmacen;
    }

    public Optional<Boolean> getPreparando() {
        return preparando;
    }

    public void setPreparando(Optional<Boolean> preparando) {
        this.preparando = preparando;
    }

    public Optional<Boolean> getEnUso() {
        return enUso;
    }

    public void setEnUso(Optional<Boolean> enUso) {
        this.enUso = enUso;
    }

    // Java language methods
    @Override
    public String toString() {
        return this.getNombre();
    }
}
