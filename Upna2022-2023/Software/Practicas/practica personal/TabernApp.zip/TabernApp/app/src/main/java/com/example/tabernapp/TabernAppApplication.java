package com.example.tabernapp;

import android.app.Application;

import com.example.tabernapp.Models.Item;
import com.example.tabernapp.Models.Tipo;

import java.util.ArrayList;
import java.util.List;

public class TabernAppApplication extends Application {

    // Lists and arrays that contains the app
    private List<Item> catalogo = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        startCatalogue();
    }

    public List<Item> getCatalogo() {
        return catalogo;
    }

    public void startCatalogue() {
        String[] nombres = {"Pan", "Reposteria", "Lacteo", "Refresco", "Snack", "Cafe", "Extra"};
        Tipo[] tipo = {Tipo.PAN, Tipo.REPOSTERIA, Tipo.LACTEO, Tipo.REFRESCO, Tipo.SNACK, Tipo.CAFE, Tipo.EXTRA};
        for (int i = 0; i < nombres.length; ++i) {
            catalogo.add(new Item(nombres[i], tipo[i],0.00, 0));
        }
    }
}
