package com.example.tabernapp.Models;

import com.parse.ParseObject;

public class ArticuloPedido extends ParseObject {
}
