<?php 

	echo file_get_contents("plantilla01.html");



?>