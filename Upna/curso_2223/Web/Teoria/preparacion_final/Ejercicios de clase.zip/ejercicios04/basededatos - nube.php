<?php 

	$servidor = "dbserver";
	$usuario = "grupo_00";
	$password = "asdfav4e";
	$basededatos = "dbgrupo_00";

	$con = mysqli_connect($servidor, $usuario, $password, $basededatos);

?>